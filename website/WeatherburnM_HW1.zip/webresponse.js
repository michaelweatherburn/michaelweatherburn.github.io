//animate words when page loads
function animateDiv(){
    $('#theDiv').removeClass()
    $('#theDiv').addClass('animate__animated animate__bounceIn')
    
}